/*
		
	some examples of OO modeling:
		1: a couple simple examples
		2: a complicated cow class
		3: a sporting team 
		4: a rock paper siscors playing game - coming soon, in work session

*/