Concepts:
	inheritance
	classes
	oop
	'single page' apps
Skills:
	modeling with objects
	serving js mvc micro-apps
Tools:
	class syntax
	browserify
	babel
Deliverables:
	a simple OO app plugin for your projects
