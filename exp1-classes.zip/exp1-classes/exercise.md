Implement a section in your project with a class-based mvc app like in the sampleApp, this will be good preparation for react
use the examples and resources in here to see how it may be done

it might:
	communicate with the server to store it's current state, or the state of some components
	manipulate several classes of data-type
	update different portions of the page with jquery
	be served statically and stored as a cookie
	...

