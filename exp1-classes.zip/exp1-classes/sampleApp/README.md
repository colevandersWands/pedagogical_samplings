A very simple express app to serve the class-based app

npm install
	yup
npm run compile
	compiles src/bundle.js inot something the browser can use and sends it to lib/bundle.js
npm run start
	starts the server to serve the app