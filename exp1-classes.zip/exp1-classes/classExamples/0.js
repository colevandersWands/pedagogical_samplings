/*
	a series on Class syntax.
	Classes are no different from the constructor functions in Banksy EXCEPT for the syntax 
		and a few other nice features

	Classes as constructor functions 
		1: super simple first example
		2: defining methods
		3: an example bank account
	a class and it's offspring
		4: defining properties in the class's constructor is different than in the body
		5: properties on objects will overwrite class objects
	third phase demonstrates the relationship between offspring of the same class
		6: offspring cannot access eachother
 	classes inheriting from classes
 		7: keyword extends
 		8: generalized overwriting rule
 		9: 'super' for constructor 
 		10: and for methods
	getters and setters:
		11: it's good to use them
*/